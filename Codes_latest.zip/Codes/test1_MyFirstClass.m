clear; close all; clc;

% n = 3;
% modelSEIR1 = dynamicalModel_SEIRn;
% modelSEIR1.n = n;
% modelSEIR1.N = [4030711645 * 0.04;...
%     4030711645 * 0.96;...
%     3957932033]; % default global population size
% modelSEIR1.C = readmatrix('globalContactMatrix.xlsx');
% modelSEIR1.omega = 1/12;
% modelSEIR1.gamma = 1/11;
% modelSEIR1.VE = 0;

% n = 1;
% modelSEIR1 = dynamicalModel_SEIRn;
% modelSEIR1.n = n;
% modelSEIR1.N = 4030711645 + 3957932033;
% modelSEIR1.C = zeros(n); modelSEIR1.C(1) = 13.45;
% modelSEIR1.omega = 1/12;
% modelSEIR1.gamma = 1/11;
% modelSEIR1.VE = 0;

n = 2;
modelSEIR1 = dynamicalModel_SEIRn;
modelSEIR1.n = n;
VC = 0.8 * 0.345; % current vaccination coverage
modelSEIR1.N = 7.9886e9 * [(1-VC); VC];
modelSEIR1.C = repmat(13.45 * [(1-VC), VC], [2,1])
modelSEIR1.omega = 1/12;
modelSEIR1.gamma = 1/11;
modelSEIR1.VE = [0, 0.85] .* ones(2,1);


whos modelSEIR1

%% read data
k = 6;  % number of sheet
[~,sheetNames,~] = xlsfinfo('OtherCountries.xlsx');
data = readtable('OtherCountries.xlsx', 'Sheet', sheetNames{k});

tData = days(data.Confirmation - data.Confirmation(1)) + 1; % time in days
dData = data.Confirmation;  % time in dates
IData = data.Cases;

%% fit
model1 = fitModel(modelSEIR1, tData, IData)

%% predict with intervention

% interventions
dgamma = 0.5;
dC = 1;
dq = 1;

model2 = model1;
model2.gamma = model1.gamma / dgamma;
model2.C = model1.C * dC;
model2.q = model1.q * dq;

tSpan1 = linspace(tData(1), tData(end), 1e3);
tSpan2 = model1.tSpan(end) + linspace(0, 10, 1e3);
x1 = predictModel(model1, tSpan1, model1.xInit);
x2 = predictModel(model2, tSpan2, x1(end,:));

dI1.value = sum(model1.omega * x1(:,n+1:2*n),2);
dI2.value = sum(model2.omega * x2(:,n+1:2*n),2);
dI1.lb = icdf('Poisson', 0.05, dI1.value);
dI1.ub = icdf('Poisson', 0.95, dI1.value);
dI2.lb = icdf('Poisson', 0.05, dI2.value);
dI2.ub = icdf('Poisson', 0.95, dI2.value);
%% visualize
fig = figure; 
hold on;
p1 = fill([tSpan1, flip(tSpan1)], [dI1.lb; flip(dI1.ub)], 'red');
p1.FaceColor = [1 0.8 0.8];
p1.EdgeColor = 'none';
p2 = fill([tSpan2, flip(tSpan2)], [dI2.lb; flip(dI2.ub)], 'red');
p2.FaceColor = [1 0.8 0.8];
p2.EdgeColor = 'none';

plot(tData, IData, 'bo');  % training data
plot(tSpan1, dI1.value, 'r-'); % model validation
plot(tSpan2, dI2.value, 'r-.'); % model predication
YLim = fig.Children.YLim;
plot(tSpan1(end) * ones(1e3, 1), linspace(YLim(1),YLim(2), 1e3),'black-.');





title([sheetNames{k} + ", reduction of (\gamma, q, c) set as (" + dgamma + ", " + dC + ", " + dq + ')']);
legend('', '', 'Training Data', 'Model Validation', 'Model Predication', 'Start of Intervention', 'Location', 'northwest');

