clc; close all; clc;

%% denoise the daily new report curve via gaussian filter

% method parameters
kernelSize = 7;
sigma = 4;

% read data and denoise
data = readtable('data0814.xlsx');
t = data.Date;
I = data.Cases;
I_denoised = gaussianFilter1D(I, kernelSize, sigma);
cumI = cumsum(I);

res = sum(I) - sum(I_denoised)

% visualize
figure;
t1 = tiledlayout('flow');
ax1 = nexttile;
plot(t, I, '.');
title('Original Curve')

ax2 = nexttile;
plot(t, I_denoised, '.')
title('Denoised Curve')

ax3 = nexttile;
plot(t, cumI, '.');
title('Curve of Cummulation')

% write the denoisde data
denoisdeTable = data;
denoisdeTable.Cases = I_denoised;
writetable(denoisdeTable, 'denoisedData0814.xlsx');

%%% nested functions
function yData = gaussianFilter1D(xData, kernelSize, sigma)
% gaussian filter for 1-dimension signal

n = size(xData,1);
t = floor(kernelSize / 2);
yData = zeros(size(xData));

kernel = normpdf(-t:t, 0, sigma); kernel = kernel ./ sum(kernel);
xData = [zeros(t,1); xData; zeros(t,1)];

for i = 1:n
    yData(i) = sum(xData(i:i+2*t) .* kernel');
end
end
